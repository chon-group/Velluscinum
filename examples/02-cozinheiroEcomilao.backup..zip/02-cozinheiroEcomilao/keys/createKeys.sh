#!/bin/bash
java -jar jason-bigchaindb-driver.jar createKeys banco
java -jar jason-bigchaindb-driver.jar createKeys cozinheiro
java -jar jason-bigchaindb-driver.jar createKeys comilao
